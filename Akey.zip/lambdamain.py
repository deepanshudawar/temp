from akeyless_cloud_id import CloudId
import akeyless
def lambda_handler(event, context):
  configuration = akeyless.Configuration(
          host = "https://api.akeyless.io"
  )

  api_client = akeyless.ApiClient(configuration)
  api = akeyless.V2Api(api_client)

  cloud_id = CloudId()
  id = cloud_id.generate()

  body = akeyless.Auth(access_id='p-88dsjutn9ljn',access_type='aws_iam',
          cloud_id=id)
  res = api.auth(body)
  token = res.token

  body = akeyless.GetSecretValue(names=['MyFirstSecret'], uid_token=token)
  res = api.get_secret_value(body)
  print(res['MyFirstSecret'])