# coding: utf-8

# flake8: noqa

from __future__ import absolute_import

from akeyless_cloud_id.cloud_id import CloudId

__version__ = "0.1.4"
